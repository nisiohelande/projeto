const proj_configseries ="https://nisioex.herokuapp.com";
export default proj_configseries;