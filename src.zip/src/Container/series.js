import React, { Component } from 'react'
import Axios from 'axios'
import proj_configseries from '../Config/Config_series'

export default class series extends Component {
    constructor(props) {
        super(props)

        this.state = {
            series: [],
            isLoading: false
        }
        
    }
    componentDidMount() {
        this.setState({ isLoading: true })
        Axios.get(`${proj_configseries}/series`).then((res) => {
            const { Series } = res.data.data
            this.setState({ Series: series, isLoading: false })
        })

    }
    renderSeries(series) {
        return (
            <li key={series._id} className="list-group-item">
                <h3 className="text-center">{series.titulo}</h3>
                <div className= "text-center">
                    <input type='image' style={{width: '500px'}} src={series.imagem}className="img-fluid img-thumbnail"/>
                </div>
                <div>
                    <button type="button" className="btn btn-info" style={{marginRight: '20px'}}>Visualisar</button>
                    <button type="button" className="btn btn-danger">Deletar</button>
                </div>

            </li>
        )
    }

    render() {
        return (
            <div className="container">

                {
                    this.state.isLoading ?
                        <span> Carregando Series </span>
                        :
                        <ul className="list-group">
                            {this.state.series.map(this.renderSeries)}
                        </ul>
                }

            </div>
        )
    }
}