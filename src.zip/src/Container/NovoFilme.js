import React, { Component } from 'react'

export default class NovoFilme extends Component {
    render() {
        return (
            <div className="intro-section">
                <h1>Nova Receita</h1>
                <form className="container" style={{ padding: '80px' }}>
                    <div className="form-group" >
                        <input type="text" className="form-control" placeholder="Nome da Receita" />
                    </div>
                    <div className="form-group" >
                        <textarea className="form-control" rows="3" placeholder="Ingredientes">
                        </textarea>
                    </div>
                    <div className="form-group" >
                        <textarea className="form-control" rows="4" placeholder="Modo de Preparo" >
                        </textarea>
                    </div>
                    <div className="form-group" >
                        <input type="text" className="form-control" placeholder="Link da Imagem" />
                    </div>
                    <button type="submit" className="btn btn-primary">Salvar receita</button>
                </form>
            </div>


        )
    }
}
