const proj_config = "https://nisioex.herokuapp.com";
export default proj_config;